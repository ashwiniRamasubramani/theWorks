package com.CheapestHotel.demo.data;

public class Hotel {

	private String name;
	private AddressType address;
	private String phone;
	private String rate;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public AddressType getAddress() {
		return address;
	}
	public void setAddress(AddressType address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	
	@Override
	public String toString() {
		return " \n Hotel {" + "Name =" + name
                + ", Address =" + address 
                + ", Phone =" + phone  
                + ", Rate =" + rate + 
                '}';
		
	}
}
