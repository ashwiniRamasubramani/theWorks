package com.CheapestHotel.demo.data;

public class AddressType {

	private String cityName;
	private String countryCode;
	private String postalCode;
	private String stateCode;
	private String[] lines;
	
	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String[] getLines() {
		return lines;
	}

	public void setLines(String[] lines) {
		this.lines = lines;
	}

	@Override
	public String toString() {
		return "{" 
				+ " City =" + cityName 
                + ", Postal Code =" + postalCode  
                + ", Country =" + countryCode + 
                '}';
		
	}
	
}
