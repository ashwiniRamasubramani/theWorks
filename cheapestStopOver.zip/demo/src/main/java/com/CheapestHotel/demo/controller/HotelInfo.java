/**
 * A Rest Controller API, gives Hotel Specific information
 * Uses a third party Amadeus API for providing hotel information
 * 
 */

package com.CheapestHotel.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.CheapestHotel.demo.data.*;

import com.amadeus.Amadeus;
import com.amadeus.Params;
import com.amadeus.exceptions.ResponseException;
import com.amadeus.resources.HotelOffer;

@RestController
public class HotelInfo {

	private List<Hotel> hotelListing;
	private String location;
	private Date fromDate;
	private Date toDate;
	
	//reading property values
	@Value("${default.apiKey}")
	private String clientKey;
	
	@Value("${default.apiSecret}")
	private String clientSecurity;
	
	private final static Logger LOGGER = Logger.getLogger(HotelInfo.class.getName());

	public List<Hotel> getHotelListing() {
		return hotelListing;
	}

	public void setHotelListing(List<Hotel> hotelListing) {
		this.hotelListing = hotelListing;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	@RequestMapping("/hotelListing")
	public String bestHotelDeals(@RequestParam(value = "loc", required = true) String loc,
			@RequestParam(value = "checkIn", required = true) String checkIn,
			@RequestParam(value = "checkOut", required = true) String checkOut) {
		
		hotelListing = new ArrayList<Hotel>();
		
		try {
			//get list of hotels from given location
			HotelOffer[] offers =getHotelsAtLoc(loc,checkIn,checkOut); 
			int size = 0;
			
			//process response
			if(offers.length ==0) {
				return "No Hotels found";
			}
			else if(offers.length>2)
				 size=2;
			else
				size=offers.length;
			
				
			//Convert API response to native Java class
			
			for(int i=0; i<=size ;i++) {
				Hotel myHotelObj = new Hotel();
				myHotelObj.setName(offers[i].getHotel().getName());
				AddressType addObj = new AddressType();
				com.amadeus.resources.HotelOffer.AddressType respAddObj = offers[i].getHotel().getAddress();
				addObj.setCityName(respAddObj.getCityName());
				addObj.setCountryCode(respAddObj.getCountryCode());
				addObj.setStateCode(respAddObj.getStateCode());
				addObj.setLines(respAddObj.getLines());
				addObj.setPostalCode(respAddObj.getPostalCode());
				myHotelObj.setAddress(addObj);
				myHotelObj.setPhone(offers[i].getHotel().getContact().getPhone());
				
				if(offers[i].getOffers()[0].getPrice().getTotal()!=null)
					myHotelObj.setRate(offers[i].getOffers()[0].getPrice().getTotal());
				else
					myHotelObj.setRate(offers[i].getOffers()[0].getPrice().getBase());
				
				hotelListing.add(myHotelObj);
			}
			
			} catch (ResponseException e) {
			LOGGER.log( Level.SEVERE, e.toString(), e );
		}
				
		//return list.
		return "The Listing of Hotels with best value are : " + getHotelListing();
	}
	
/**
 * The method creates Amadeus environment and contacts the Hotel Service API
 * @param loc IATA standard location name of the city
 * @param checkInDate Date of check in
 * @param checkOutDate Date of check out
 * @return returns the list of hotels obtained as rest response
 * @throws ResponseException
 */
	private HotelOffer[] getHotelsAtLoc(String loc,String checkInDate, String checkOutDate) throws ResponseException
	{
		Amadeus amadeus = Amadeus
		        .builder(clientKey, clientSecurity)
		        .setLogLevel("debug")
		        .build();
	
		HotelOffer[] offers = null;
		
		try {
			offers = amadeus.shopping.hotelOffers.get(Params
					  .with("cityCode",loc)
					  .and("CheckInDate",checkInDate)
					  .and("CheckOutDate", checkOutDate)
					  .and("view", "LIGHT"));
	    
		} catch (ResponseException e) {
			LOGGER.log( Level.SEVERE, e.toString(), e );
			throw e;
		}
		
		return offers;
	}

}
