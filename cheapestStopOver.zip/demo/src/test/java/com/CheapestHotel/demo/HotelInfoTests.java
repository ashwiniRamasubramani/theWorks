/*package com.CheapestHotel.demo;


import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.springframework.test.web.servlet.MockMvc;

import com.CheapestHotel.demo.controller.HotelInfo;

@RunWith(SpringRunner.class)
@WebMvcTest(HotelInfo.class)
public class HotelInfoTests {
	
	private final static Logger LOGGER = Logger.getLogger(HotelInfoTests.class.getName());
	
	@Autowired
    private MockMvc mockMvc;

	@Test	
	public void bestHotelDeatsTest() {
		
		try {
			
			this.mockMvc.perform(get("/hotelListing")).andDo(print()).andExpect(status().isOk())
	        .andExpect(content().string(containsString("The Listing of Hotels with best value are")));
		}
		catch(Exception e ) {
			LOGGER.log( Level.SEVERE, e.toString(), e );
		}
		
	}
}
*/