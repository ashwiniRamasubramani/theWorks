
# CheapestStopOver

This is a service designed to get the top cheapest accomodation
once the Location is given in IATA format and Check in /Check out dates are given in YYYY-MM-DD format

## Running the service in development
```
java -jar target/demo-0.0.1-SNAPSHOT.jar
```

The logs currently, come in standard output, no files are configured.
The API specific key/secret are available in applications.properties file

### Accessing the service
 Below is the example of invoking the service URL
```
http://localhost:8080/hotelListing?loc=LON&checkIn=2019-02-11&checkOut=2019-02-12
```
 

