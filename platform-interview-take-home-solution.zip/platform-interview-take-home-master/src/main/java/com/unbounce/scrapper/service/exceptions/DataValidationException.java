package com.unbounce.scrapper.service.exceptions;

import com.unbounce.scraper.service.interfaces.ErrorCode;

public class DataValidationException extends Exception
{
    private static final long serialVersionUID = -5766450179899701032L;
    private ErrorCode itsErrorCode;

    public DataValidationException(ErrorCode anErrorCode, Throwable cause)
    {
        super(cause);
        itsErrorCode = anErrorCode;
    }

    public DataValidationException(ErrorCode anErrorCode)
    {
        super();
        itsErrorCode = anErrorCode;
    }

    /**
     * @return the itsErrorCode
     */
    public ErrorCode getErrorCode() {
        return itsErrorCode;
    }


}

