package com.unbounce.scraper.service.interfaces;

public enum ErrorCode
{
    DataNotFound                (1100),

    DuplicatedValue             (1300),

    PersistenceError            (1400),

    DefaultData                 (1500);


    private int itsErrorValue;

    public int getErrorCode()
    {
        return itsErrorValue;
    }

    private ErrorCode(int aValue)
    {
        itsErrorValue = aValue;
    }

    public static ErrorCode fromValue(int aValue)
    {
        for(ErrorCode myError : ErrorCode.values())
        {
            if(myError.getErrorCode() == aValue)
            {
                return myError;
            }
        }

        throw new IllegalArgumentException("Unknown error code: " + aValue);
    }
}
