package com.unbounce.scraper;

public interface MessageHandler {
    void handleMessage(String message);
}
