package com.unbounce.scraper.service.implementation;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.unbounce.scraper.provided.htmlparser.Document;
import com.unbounce.scraper.provided.jsontool.JsonMapParser;
import com.unbounce.scraper.bootstrap.restricted.Message;
import com.unbounce.scraper.service.interfaces.ScrapperService;
import com.unbounce.scrapper.service.exceptions.DataValidationException;
import com.unbounce.scraper.dao.implementation.DaoImplmentation;

public class ScrapperServiceImplementation implements ScrapperService {
	 private static final Logger LOGGER = LoggerFactory.getLogger(ScrapperServiceImplementation.class);
	private Map<String,Long> data;

	@Override
	public void inputServiceMessage(Message message)throws DataValidationException{
		DaoImplmentation myDaoImplmentation = new DaoImplmentation();
		data = new HashMap<String,Long>();
		
		try {
					JsonMapParser myJasonMapParser = new JsonMapParser();
					Map<String,Object> jsonMap = new HashMap<String,Object>();
					jsonMap = myJasonMapParser.parseJson(message.getBody());
					
					for (Map.Entry<String, Object> entry : jsonMap.entrySet()) {
						String key = entry.getKey();
					    String value = entry.getValue().toString();
				        if(key.equalsIgnoreCase("url")) {
				        	findAsset(value);
				        }
				    }
					
					if(!data.isEmpty())
						myDaoImplmentation.writeData(data);
	
		  
		}catch (DataValidationException e) {
			LOGGER.error("Error scrapping the message", e);
		}
		
		
	}

	/*
	 * Get Document object after parsing the html from given url.
	 */
	public void findAsset(String url) {

		org.jsoup.nodes.Document document;
		
		try {
		
		document = Jsoup.connect(url).get();
		Document myDocument= new Document(document);
		List<String> resources = myDocument.getResourceURLs();
		System.out.println("Resources " +resources );
		for(String res :resources) {
			data.put(res,(long) res.length());
		}
		
		} catch (IOException e) {
			LOGGER.error("Error getting  asset", e);
	}
	}

}
