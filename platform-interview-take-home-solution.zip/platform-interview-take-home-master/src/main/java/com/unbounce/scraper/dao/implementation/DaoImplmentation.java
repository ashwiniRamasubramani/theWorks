package com.unbounce.scraper.dao.implementation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/*Need to create a Generic DAO interface
 * Generic DOA pushes data to queue/file/DB
 * ProxyDB interface gets DB credentials from Constants and creates DB Connection
 *ProxyQueue would get queue specification and publish message
 * 
 */

import com.unbounce.scraper.provided.database.*;
import com.unbounce.scraper.provided.eventbroadcast.*;
import com.unbounce.scraper.service.interfaces.ErrorCode;
import com.unbounce.scrapper.service.exceptions.DataValidationException;

public class DaoImplmentation {

	public void writeData(Map<String,Long> data) throws DataValidationException {
	   	    
		List<String> response = new ArrayList<>();
		try {
		
		DatabaseClient myDatabaseClient = new DatabaseClient("fake String");
		
			for (Map.Entry<String, Long> entry : data.entrySet()) {
				String key = entry.getKey();
				long value = entry.getValue();
				System.out.println("Key : " + key + " Value : " + value);
				myDatabaseClient.recordPageSize(key, value);
			}
		 
		EventBroadcaster myEventBroadcaster = new EventBroadcaster(null);
		myEventBroadcaster.broadcastEvent("fake queue");
		
		
		}catch (IOException e) {
			response.add(ErrorCode.PersistenceError.toString());
			throw  new DataValidationException(ErrorCode.PersistenceError, e);
			
		}
		
		
	}

	
}
