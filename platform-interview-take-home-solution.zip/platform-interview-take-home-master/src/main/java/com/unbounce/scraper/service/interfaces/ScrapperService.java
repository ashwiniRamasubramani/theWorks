package com.unbounce.scraper.service.interfaces;


import com.unbounce.scraper.bootstrap.restricted.Message;
import com.unbounce.scrapper.service.exceptions.DataValidationException;

public interface ScrapperService  {
  
/*Takes the service message to process
 *Gives the result consisting of error code , Message */
  void inputServiceMessage(Message message) throws DataValidationException;
}
